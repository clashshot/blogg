<div class="container">

    <h1>Verification</h1>
    <div class="box">

        <!-- echo out the system feedback (error and success messages) -->
        <?php $this->renderFeedbackMessages(); ?>

        <a href="<?php echo Config::get('URL'); ?>">Go back to home page</a>
    </div>

</div>
