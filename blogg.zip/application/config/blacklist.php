<?php
/**
 * Created by PhpStorm.
 * User: Rickardh
 * Date: 2016-10-17
 * Time: 18:03
 */
return array(
    'admin', 'blog', 'dashboard', 'error', 'index', 'login', 'profile', 'register', 'user', 'avatars', 'css', 'js'
);